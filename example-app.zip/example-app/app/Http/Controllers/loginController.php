<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class loginController extends Controller
{
    public function index(){

    	return view('login');
    }

    public function verify(Request $req){
    	echo "posted";
  		 $value = $req->session()->get('username');
		 $value2 = $req->session()->get('password');

		 echo $value2;
    	
    	//return redirect()->action([homeController::class, 'index']);
    	return view('home.index');
    	//return "posted";
    }

}
