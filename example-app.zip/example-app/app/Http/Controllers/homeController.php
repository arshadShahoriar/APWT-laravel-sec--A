<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class homeController extends Controller
{
    public function index(){

    	return view('home.index');
    }

    public function verify(Request $req){
    	echo "posted";
    	
    	return "posted";
    }

}
